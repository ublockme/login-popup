<form class="xoo-aff-field-settings xoo-aff-fs-{{data.type_data.type}}" id="{{data.field_id}}">
	<div class="xoo-aff-label xoo-aff-label-{{data.type_data.type}}">
		<span class="xoo-aff-type-icon {{data.type_data.icon}}"></span>
		<span>{{data.type_data.title}}</span>
		<span></span>
	</div>
	<div class="xoo-aff-fs-wrap">{{{data.fields_html}}}</div>
</form>